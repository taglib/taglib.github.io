/***************************************************************************
    copyright            : (C) 2003 by Scott Wheeler
    email                : wheeler@kde.org
 ***************************************************************************/

/***************************************************************************
 *   This library is free software; you can redistribute it and/or modify  *
 *   it  under the terms of the GNU Lesser General Public License version  *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful, but   *
 *   WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  *
 *   USA                                                                   *
 ***************************************************************************/

#include <tfile.h>
#include <tbytevectorlist.h>

#ifndef TAGLIB_OGGFILE_H
#define TAGLIB_OGGFILE_H

namespace TagLib {

  namespace Ogg {

    class File : public TagLib::File
    {
    public:
      virtual ~File();

      /*!
       * Returns the packet contents for the i-th packet (starting from zero)
       * in the Ogg bitstream.
       *
       * \warning The requires reading at least the packet header for every page
       * up to the requested page.
       */
      ByteVector packet(uint i);

      /*!
       * Sets the packet with index \a i to the value \a p.
       */
      void setPacket(uint i, const ByteVector &p);

      virtual void save();

    protected:
      /*!
       * This should always be constructed via subclasses and as such is
       * protected.
       */
      File(const String &file);

    private:
      /*!
       * Reads the next page and updates the internal "current page" pointer.
       */
      bool nextPage();
      void writePageGroup(const List<int> &group);

      class FilePrivate;
      FilePrivate *d;
    };

  }
}

#endif
