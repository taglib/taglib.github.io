#include "../taglib/mpc/mpcproperties.h"
