#include "../taglib/wavpack/wavpackproperties.h"
